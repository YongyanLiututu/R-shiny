library(shiny)
library(leaflet)
library(ggExtra)
library(dplyr)
library(httr)
library(ggiraph)
library(circlize)
library(tidyr)
library(plotly)
library(viridis)
library(scales)
library(ggplot2)
library(ggridges)
library(jsonlite)
library(leaflet.extras)



data <- read.csv("weatherAUS.csv")
data$Date <- as.Date(data$Date, tryFormats = c("%d-%m-%Y"))
city_coordinates <- data.frame(
  Location = c("Albury", "Cobar", "Moree", "Newcastle", "Penrith", "Sydney", "Wollongong", "Canberra",
               "Tuggeranong", "Ballarat", "Bendigo", "Sale", "Melbourne", "Mildura", "Nhil", "Watsonia",
               "Brisbane", "Cairns", "Townsville", "Adelaide", "Nuriootpa", "Woomera", "Witchcliffe",
               "Perth", "Hobart", "Launceston", "Darwin", "Katherine", "Uluru", "PearceRAAF", "BadgerysCreek",
               "CoffsHarbour", "NorahHead", "NorfolkIsland", "SydneyAirport", "WaggaWagga", "MountGinini",
               "MelbourneAirport", "Portland", "Dartmoor", "GoldCoast", "MountGambier", "Albany",
               "PerthAirport", "SalmonGums", "Walpole", "AliceSprings", "Williamtown", "Richmond"),
  
  Latitude = c(-36.0804766, -31.4983333, -29.4617202, -32.927, -33.751, -33.8698439, -34.4278083,
               -35.2975906, -35.4209771, -37.5623013, -36.7590183, -38.103, -37.8142454, -34.195274,
               -35.4713087, -37.7109468, -27.4689682, -16.9206657, -19.2569391, -34.9281805, -34.4693354,
               -31.1999142, -34.0263348, -31.9558933, -42.8825088, -41.4340813, -12.46044, -14.4646157,
               -25.3455545, -31.66778, -33.922, -30.2986, -33.2817, -29.040835, -33.9399, -35.118,
               -35.5292, -37.6690, -38.3442, -37.9167, -28.0167, -37.8318, -35.0275, -31.9403, -32.9825,
               -34.9799, -23.6980, -32.7941, -33.6007),
  
  Longitude = c(146.9162795, 145.8344444, 149.8407153, 151.776, 150.693, 151.2082848, 150.893054,
                149.1012676, 149.0921341, 143.8605645, 144.2826718, 147.067, 144.9631732, 142.1503146,
                141.3062355, 145.0837808, 153.0234991, 145.7721854, 146.8239537, 138.5999312, 138.9939006,
                136.8253532, 115.1004768, 115.8605855, 147.3281233, 147.1373496, 130.8410469, 132.2635993,
                131.036961474702, 116.015, 150.777, 153.1094, 151.5758, 167.954712, 151.1753, 147.3673,
                148.7767, 144.8410, 141.6059, 141.2833, 153.4000, 140.7826, 117.8844, 115.9668, 121.6350,
                116.7335, 133.8807, 151.8382, 150.7497)
)
# Find longitude and latitude based on the city name
get_coordinates <- function(city_name) {
  
  city_coords <- city_coordinates[city_coordinates$Location == city_name,]
  
  if (nrow(city_coords) > 0) {
    lat <- city_coords$Latitude
    lon <- city_coords$Longitude
    message(paste("City:", city_name, "Lat:", lat, "Lon:", lon))  
    return(c(lat, lon))
  } else {
    message(paste("No coordinates found for:", city_name))  
    return(c(NA, NA))  
  }
}

year_min <- min(as.numeric(format(data$Date, "%Y")), na.rm = TRUE)
year_max <- max(as.numeric(format(data$Date, "%Y")), na.rm = TRUE)

# UI 
ui <- fluidPage(
  div(
    h1("Australia Climate Dashboard",
       
       align = "center",
       style = "
       font-size: 48px;
       font-weight: bold;
       font-family: 'Arial Black', Gadget, sans-serif;
       background: linear-gradient(45deg, #2363a6, #4facfe);
       -webkit-background-clip: text;
       -webkit-text-fill-color: transparent;
       text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
       margin-bottom: 20px;
       margin-left: 130px;  
     ")
  ),
  
  tags$head(
    tags$style(HTML("
      body {
       
        background-color: #f0f0f0;
        color: #333;
      }
     
      .tab-pane {
        background-color: #ffffff;
        border-radius: 8px;
        padding: 15px;
        width:780px;
      }
      .nav-pills > li > a {
        color: #333;
        font-weight: bold;
      }
      .nav-pills > li.active > a {
        background-color: #333;
        color: #fff;
      }
       .sidebar {
    background: linear-gradient(135deg, #e3f2fd, #2196f3);  
    color: white;
    border-radius: 10px;   
    padding: 20px;
    box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);  
    font-family: 'Arial', sans-serif;  
    font-size: 16px;
  }
  .sidebar a {
    color: white;  
    text-decoration: none;  
    padding: 10px 0;
    display: block;
    transition: all 0.3s ease;  
  }
  .sidebar a:hover {
    background-color: rgba(255, 255, 255, 0.2);  
    border-radius: 5px;
    transform: scale(1.05);  
  }
  .sidebar i {
    font-size: 20px;  
    margin-right: 10px;
  }
       .flex-container {
      display: flex;
      justify-content: space-between;
    }
    .left-panel {
      flex: 1;
      padding-right: 20px;
    }
    .right-panel {
      flex: 0.4; 
      display: flex;
      flex-direction: column;
    }
   .well {
    min-height: 20px;
    margin: 20px 0 20px -10px; 
    margin: 20px 0;
    width: 100%; 
    max-width: 600px; 
    background-color: #ffffff;
    border: 1px solid #d1d1d1;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1),
                inset 0 1px 2px rgba(0, 0, 0, 0.1);
    transition: box-shadow 0.3s ease;
   }
    .nav-tabs>li.active>a {
    color: #555;
    cursor: default;
    background: linear-gradient(to bottom, #ffffff, #f8f8f8); 
    border: 1px solid #ddd;
    border-bottom-color: transparent;
    border-radius: 8px; /* Slightly increased border radius for softer corners */
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.15);
    transition: box-shadow 0.3s ease, transform 0.3s ease, background 0.3s ease; 
  }
    .nav-tabs>li.active>a:hover {
    background: linear-gradient(to bottom, #fefefe, #f0f0f0); 
    box-shadow: 0 6px 15px rgba(0, 0, 0, 0.2); 
    transform: translateY(-1px);
    }
    .well:hover {
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2), 
                inset 0 1px 3px rgba(0, 0, 0, 0.2); 
    }
    #right-panel {
     position: absolute;  
     top: 20px;           
     right: 20px;         
     background-color: rgba(255, 255, 255, 0.6); 
     padding: 15px;
     border-radius: 8px;
     z-index: 1000;      
      }

    .sliderInput {
    background-color: rgba(255, 255, 255, 0.6); 
    }

    .plotOutput {
       background-color: rgba(255, 255, 255, 0.6); 
    }
    .right-panel .sliderInput {
      margin-bottom: 20px; 
    }
    .absolute-panel { 
    position: absolute !important;  
    bottom: 0px !important;        
    right: -180px !important;         
    background-color: rgba(255,255,255,0.8);  
    padding: 10px;                 
    z-index: 500;                  
    }
   h1 { 
        font-family: Arial, sans-serif; 
        font-weight: bold; 
        text-align: center; 
        color: #4CAF50; 
        margin-bottom: 20px;
      }
    h2 {
    width:950px;
    font-family: 'Helvetica Neue', Arial, sans-serif; 
    font-size: 24px; 
    text-align: center;
    color: #333; 
    margin-bottom: 10px; 
    letter-spacing: 0.5px; 
    text-transform: uppercase; 
    text-shadow: 0 1px 3px rgba(0, 0, 0, 0.1); 
    background-color: #f5f5f5; 
    padding: 20px;
    border-radius: 8px; 
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1); 
    }
      p {
        font-family: Arial, sans-serif;
        font-size: 14px;
        color: #333;
        text-align: center;
        margin-bottom: 20px;
      }
        .temp-details-box {
      border: 1px solid #ccc; 
      padding: 20px; 

      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); 
      border-radius: 10px; 
      background: linear-gradient(135deg, #f8f8f8, #e3e3e3);
      font-family: 'Montserrat', sans-serif;
    }
    
    .temp-details-title {
      font-size: 18px; 
      font-weight: bold; 
      color: #2363a6; 
      margin-bottom: 10px;
    }
    
    .temp-details-content {
      font-size: 16px; 
      font-weight: 500; 
      color: #555; 
      margin-bottom: 5px;
    }
    
    .temp-change-title {
      font-size: 16px; 
      font-weight: 600;
    }
    
    .temp-change-icon-up {
      color: red; 
      font-size: 20px;
    }
    
    .temp-change-icon-down {
      color: green; 
      font-size: 20px;
    }
      .selectInput {
        margin-left: auto;
        margin-right: auto;
        width: 50%;
        text-align: center;
      }
      .plotOutput {
        margin-left: auto;
        margin-right: auto;
        text-align: center;
      }
        .total-rainfall-legend {
    font-family: Arial, sans-serif; 
    font-size: 8px; 
    color: #000;
    font-weight: bold;
  }
  .total-rainfall-legend div {
    padding: 3px 5px; 
  }
  .total-rainfall-legend .rainfall-label {
    font-size: 8px;
    color: #333;
  }
      .col-sm-8, .col-sm-4 {
    padding-left: 0.5px !important;
    padding-right: 0.5px !important;
      }
       .col-sm-2 {
    padding-left: 0.5px !important;
    padding-right:10px !important;
      }
  
  .tab-content {
        position: relative;
        transition: opacity 0.5s ease-in-out;
      }
      .tab-content.fade-out {
        opacity: 0;
      }
      .tab-title {
      font-family: 'Sitka Heading Semibold', sans-serif;
      font-size: 18px;
      font-weight: 600; 
      color: #2363a6;
    }
      .tab-content.fade-in {
        opacity: 1;
      } 
      .custom-select-container {
        display: flex;
        align-items: center;
        justify-content: space-between;
      }
      .custom-select {
        border-radius: 5px;
        border: 1px solid #ccc;
        padding: 5px 10px;
        background-color: #f8f8f8;
        width: 100%;
        box-sizing: border-box;
      }
      .custom-select:focus {
        border-color: #007bff;
        box-shadow: 0 0 0 0.2rem rgba(38, 143, 255, 0.25);
      }
      .custom-column {
        padding: 0 10px;
      }
  
    ")),
    tags$script(HTML("
      Shiny.addCustomMessageHandler('fadeTab', function(tabName) {
        $('.tab-content').addClass('fade-out');
        setTimeout(function() {
          $('.tab-content').removeClass('fade-out').addClass('fade-in');
          $('#' + tabName).addClass('active').siblings().removeClass('active');
        }, 500);
      });
    "))
  ),
  
  sidebarLayout(
    sidebarPanel(
      actionLink("to_temperature", label = tagList(icon("thermometer-half"), "Temperature")),
      br(), br(),
      actionLink("to_rain", label = tagList(icon("cloud-rain"), "Rain")),
      br(), br(),
      actionLink("to_wind", label = tagList(icon("wind"), "Wind")),
      br(), br(),
      actionLink("to_explore", label = tagList(icon("search"), "Explore")), 
      br(), br(),
      actionLink("to_about", label = tagList(icon("info-circle"), "About")),
      width = 2
    ),
    
    mainPanel(
      tabsetPanel(id = "main_panel",
                  
                  # Temperature
                  tabPanel("Temperature",
                           fluidRow(
                             column(8,
                                    
                                    plotOutput("tempPlot", click = "tempPlot_click", height = "470px") 
                             ),
                             column(4, tags$div(
                               style = "display: flex; align-items: center; margin-bottom: -5px;", 
                               tags$label("Select a City:", style = "margin-right: 10px;"),
                               selectInput("city_maxmin", "",
                                           choices = unique(data$Location),
                                           width = '40%')  
                             ), 
                             uiOutput("tempDetails")  
                             )
                           )
                  ),
                  # Rain
                  tabPanel("Rain",
                           fluidRow(
                             column(8,
                                    
                                    uiOutput("rainfallTitle"),
                                    leafletOutput("rainfallMap", height = 500)  
                             ),
                             column(4,
                                    
                                    div(
                                      
                                      tags$div(
                                        style = "width: 100%; background-color: rgba(255,255,255,0.8); padding: 10px; text-align: center;",
                                        
                                        HTML('
                                             <div style="font-size: 14px; color: #000; font-weight: bold; text-align: center;">Total Rainfall</div>
                                             <div style="width: 200px; height: 20px; background: linear-gradient(to right, #eff3ff,#0d649c); margin: 0 auto;"></div>
                                             <div style="font-size: 12px; display: flex; justify-content: space-between; padding: 0 20px;">
                                             <span>2,000</span><span>12,000+</span>
                                             </div>
                                             ')
                                        
                                      ),
                                      
                                      sliderInput("yearSlider", "Select Year Range:",
                                                  min = as.numeric(format(min(data$Date), "%Y")),
                                                  max = as.numeric(format(max(data$Date), "%Y")),
                                                  value = c(as.numeric(format(min(data$Date), "%Y")),
                                                            as.numeric(format(max(data$Date), "%Y"))),
                                                  step = 1, sep = "", dragRange = TRUE),
                                      
                                      plotOutput("rainfallPlot", click = "plot_click", height = 330),
                                      
                                    )
                             ))),
                  
                  # Wind
                  tabPanel("Wind",
                           fluidRow(
                             column(8,
                                    girafeOutput("windPlot") 
                             ),
                             column(4,
                                    
                                    selectInput("location_selection", "Select Location:",
                                                choices = unique(data$Location), 
                                                selected = "Albury")
                                    ,
                                    
                                    uiOutput("windInfo")
                             )
                             
                             
                           )
                           
                  ),
                  # Explore 
                  tabPanel("Explore",
                           tabsetPanel(id = "explore_panel",
                                       tabPanel("Temperature VS Humidity",
                                                fluidRow(
                                                  column(6, class = "custom-column",
                                                         radioButtons("time_selection", "Select Time:",
                                                                      choices = c("9:00 AM", "3:00 PM", "All Day"),
                                                                      selected = "9:00 AM",
                                                                      inline = TRUE) 
                                                         
                                                  ),
                                                  column(6, class = "custom-column",
                                                         selectInput("location_selection", "Select Location:",
                                                                     choices = c(unique(data$Location)), 
                                                                     selected = "Albury")
                                                  )
                                                ),
                                                fluidRow(
                                                  column(12,
                                                         girafeOutput("tempHumidityPlot")
                                                  )
                                                )
                                       ),
                                       tabPanel("Wind Speed VS Rainfall",
                                                fluidRow(
                                                  column(3,
                                                         
                                                         selectInput("location", "Select a Location:", choices = unique(data$Location)),
                                                         
                                                         dateRangeInput("dateRange", "Select Date Range:",
                                                                        start = min(data$Date),
                                                                        end = max(data$Date),
                                                                        min = min(data$Date),
                                                                        max = max(data$Date)),
                                                         
                                                         
                                                         selectInput("colorVar", "Color by:",
                                                                     choices = c("Humidity9am", "Humidity3pm"), 
                                                                     selected = "Humidity9am"),
                                                         textOutput("correlation_info")
                                                         
                                                  ),
                                                  
                                                  
                                                  column(9,
                                                         girafeOutput("windRainPlot")
                                                  )
                                                )
                                       )
                           )
                  )
                  ,
                  # About
                  tabPanel("About",
                           tabsetPanel(
                             tabPanel("Introduction",
                                      fluidRow(
                                        column(12,
                                               div(
                                                 style = "background-color: #f9f9f9; padding: 20px; border-radius: 10px; box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);",
                                                 
                                                 # Application introduction part
                                                 h3(style = "color: #4CAF50; font-weight: bold; text-align: center;", "Application Overview"),
                                                 p(style = "font-family: Arial, sans-serif; font-size: 16px; color: #333; line-height: 1.5;",
                                                   "This application allows users to explore historical weather data from various Australian cities. You can view temperature trends, rainfall patterns, and wind data, as well as explore relationships between different weather variables, such as temperature and humidity or wind speed and rainfall."
                                                 ),
                                                 
                                                 # Function part explained
                                                 h3(style = "color: #FF9800; font-weight: bold; text-align: center;", "Application Features"),
                                                 p(style = "font-family: 'Montserrat', sans-serif; font-size: 14px; color: #333; line-height: 1.4;",
                                                   strong("1. Temperature Analysis:"), 
                                                   " Shows temperature trends for cities, with ridge plots of minimum, maximum, and average temperatures. Clicking reveals detailed stats and comparisons."
                                                 ),
                                                 p(style = "font-family: 'Montserrat', sans-serif; font-size: 14px; color: #333; line-height: 1.4;",
                                                   strong("2. Rainfall Summary:"), 
                                                   " Interactive map displaying total rainfall. Hovering reveals stats, and clicking shows daily rainfall trends."
                                                 ),
                                                 p(style = "font-family: 'Montserrat', sans-serif; font-size: 14px; color: #333; line-height: 1.4;",
                                                   strong("3. Wind Data Analysis:"), 
                                                   " Displays average wind gusts in different directions with polar bar charts, including stats on maximum wind speeds and directions."
                                                 ),
                                                 p(style = "font-family: 'Montserrat', sans-serif; font-size: 14px; color: #333; line-height: 1.4;",
                                                   strong("4. Explore Relationships Between Weather Variables:"), 
                                                   " Analyzes correlations between variables like temperature, humidity, wind speed, and rainfall using scatter plots and regression lines."
                                                 ),
                                                 
                                                 
                                                 # Dataset Introduction
                                                 h3(style = "color: #2196F3; font-weight: bold; text-align: center;", "Dataset Description & Sources"),
                                                 p(style = "font-family: 'Courier New', Courier, monospace; font-size: 14px; color: #666; line-height: 1.5;",
                                                   "This dataset contains 10 years of daily weather observations from various locations across Australia, including temperature, rainfall, humidity, and wind speed. It supports analysis of weather patterns and relationships between factors such as temperature, humidity, and wind."
                                                 ),
                                                 p(style = "font-family: Georgia, serif; font-size: 14px; color: #444; line-height: 1.5;",
                                                   "The dataset is available on Kaggle: ",
                                                   a(href = "https://www.kaggle.com/datasets/jsphyg/weather-dataset-rattle-package", "Weather Dataset (Rattle Package)", style = "color: #2196F3; text-decoration: underline;"),
                                                   ". Definitions are adapted from the Bureau of Meteorology's resources. Latest weather data, like ",
                                                   a(href = "http://www.bom.gov.au/climate/dwo/IDCJDW2801.latest.shtml", "Canberra", style = "color: #2196F3; text-decoration: underline;"),
                                                   " observations, can also be referenced."
                                                 )
                                                 
                                               )
                                        )
                                      )
                             ),
                             tabPanel("Data Viewer",
                                      fluidRow(
                                        column(12,
                                               div(style = "overflow-x: auto; max-width: 100%;",
                                                   dataTableOutput("dataTable")
                                               )
                                        )
                                      )
                             )
                           )
                  )
                  
      ))))



#  Server
server <- function(input, output, session) {
  
  
  # Filter the data based on selected city and date range
  observeEvent(input$apply_filters, {
    req(input$filter_city, input$filter_date)
    filtered_data <- data %>%
      filter(Location == input$filter_city,
             Date >= input$filter_date[1],
             Date <= input$filter_date[2])
    
    output$filtered_data_table <- renderDataTable({
      filtered_data
    })
  })
  
  
  # Filter data and calculate minimum and maximum temperatures
  observeEvent(input$city, {
    city_data <- data %>%
      filter(Location == input$city) %>%
      group_by(Date) %>%
      summarise(MinTemp = min(MinTemp, na.rm = TRUE),
                MaxTemp = max(MaxTemp, na.rm = TRUE))
  })
  
  # The sub-tab interface that jumps to when clicking on the left
  observeEvent(input$to_temperature, {
    updateTabsetPanel(session, "main_panel", selected = "Temperature")
  })
  
  
  observeEvent(input$to_rain, {
    updateTabsetPanel(session, "main_panel", selected = "Rain")
  })
  
  observeEvent(input$to_wind, {
    updateTabsetPanel(session, "main_panel", selected = "Wind")
  })
  
  observeEvent(input$to_explore, {
    updateTabsetPanel(session, "main_panel", selected = "Explore")
  })
  
  observeEvent(input$to_about, {
    updateTabsetPanel(session, "main_panel", selected = "About")
  })
  
  #Get the maximum and minimum temperatures
  city_data <- reactive({
    data %>%
      filter(Location == input$city_maxmin) %>%
      group_by(Date) %>%
      summarise(
        MinTemp = min(MinTemp, na.rm = TRUE),
        MaxTemp = max(MaxTemp, na.rm = TRUE)
      )
  })
  
  observeEvent(input$city_maxmin, {
    req(input$city_maxmin)
    
    city_data <- data %>%
      filter(Location == input$city_maxmin) %>%
      mutate(
        Year = format(Date, "%Y"),
        MeanTemp = (MinTemp + MaxTemp) / 2
      )
    
    
    output$tempPlot <- renderPlot({
      ggplot(city_data, aes(x = MeanTemp, y = Year, fill = ..x..)) +
        geom_density_ridges_gradient(scale = 3, rel_min_height = 0.01, alpha = 0.8) +  
        scale_fill_gradientn(
          colors = c("blue", "white", "red"),  # More control over the transition from blue to red
          values = scales::rescale(c(0, 20, 40)),   # Adjust this based on the range of your temperature data
          name = "Mean Temp"
        ) +
        labs(title = paste("Temperatures in", input$city_maxmin),
             x = "Temperature (°C)", y = "Year") +
        theme_minimal() +
        theme(
          plot.title = element_text(hjust = 0.5, size = 24, face = "bold", family = "Bahnschrift", color = "#0d649c"), 
          axis.title = element_text(size = 12),
          axis.text = element_text(size = 10),
          strip.text = element_text(size = 12, face = "bold"),
          legend.position = "bottom" 
        ) +
        guides(fill = guide_colorbar(title = "Mean Temp", barwidth = 20))  
    })
    
    
  })
  
  
  # Temperature map
  observeEvent(input$tempPlot_click, {
    if (is.null(input$tempPlot_click)) {
      output$tempDetails <- renderUI({
        HTML("<p>No click event detected.</p>")
      })
      return(NULL)
    }
    click_info <- input$tempPlot_click
    selected_y_value <- click_info$y
    print(paste("Clicked Y value:", selected_y_value))  
    
    # Match y value to list of years
    year_list <- c("2008", "2009", "2010", "2011", "2012", "2013", "2014", "2015", "2016", "2017")
    
    year_positions <- seq(1, length(year_list)) 
    closest_year_index <- which.min(abs(year_positions - selected_y_value))
    selected_year <- as.numeric(year_list[closest_year_index])
    print(paste("Closest Year Selected:", selected_year))  
    city_data <- data %>%
      filter(Location == input$city_maxmin) %>%
      mutate(
        Year = as.numeric(format(Date, "%Y")),
        MeanTemp = (MinTemp + MaxTemp) / 2
      )
    
    filtered_data <- city_data %>% filter(Year == selected_year)
    
    if (nrow(filtered_data) == 0) {
      output$tempDetails <- renderUI({
        HTML("<p>No data available for the selected year.</p>")
      })
      return()
    }
    
    selected_year_data <- filtered_data %>%
      summarise(
        MinTempYear = ifelse(!all(is.na(MinTemp)), min(MinTemp, na.rm = TRUE), NA),
        MaxTempYear = ifelse(!all(is.na(MaxTemp)), max(MaxTemp, na.rm = TRUE), NA),
        AvgTempYear = ifelse(!all(is.na(MeanTemp)), round(mean(MeanTemp, na.rm = TRUE), 2), "No data"),
        AvgMinTempYear = mean(MinTemp, na.rm = TRUE), 
        AvgMaxTempYear = mean(MaxTemp, na.rm = TRUE)  
      )
    
    
    if (is.na(selected_year_data$MinTempYear) || is.na(selected_year_data$MaxTempYear)) {
      output$tempDetails <- renderUI({
        HTML("<p>No temperature data available for the selected year.</p>")
      })
      return()
    }
    
    # Calculate the average of the minimum and maximum temperatures over all historical years
    historical_data <- city_data %>%
      summarise(
        HistoricalAvgMinTemp = mean(MinTemp, na.rm = TRUE),  
        HistoricalAvgMaxTemp = mean(MaxTemp, na.rm = TRUE)   
      )
    
    if (is.na(historical_data$HistoricalAvgMinTemp) || is.na(historical_data$HistoricalAvgMaxTemp)) {
      historical_data$HistoricalAvgMinTemp <- "No data"
      historical_data$HistoricalAvgMaxTemp <- "No data"
    }
    
    # Calculate the percentage change from the historical average
    min_temp_change <- ifelse(!is.na(selected_year_data$AvgMinTempYear) && !is.na(historical_data$HistoricalAvgMinTemp),
                              round(((selected_year_data$AvgMinTempYear - historical_data$HistoricalAvgMinTemp) / historical_data$HistoricalAvgMinTemp) * 100, 2),
                              "No data")
    max_temp_change <- ifelse(!is.na(selected_year_data$AvgMaxTempYear) && !is.na(historical_data$HistoricalAvgMaxTemp),
                              round(((selected_year_data$AvgMaxTempYear - historical_data$HistoricalAvgMaxTemp) / historical_data$HistoricalAvgMaxTemp) * 100, 2),
                              "No data")
    
    # Corrected cases where change percentage is greater than 100 or less than -100
    min_temp_change <- ifelse(min_temp_change > 100 | min_temp_change < -100, ">100%", min_temp_change)
    max_temp_change <- ifelse(max_temp_change > 100 | max_temp_change < -100, ">100%", max_temp_change)
    
    # Dynamically generate displayed HTML
    output$tempDetails <- renderUI({
      req(selected_year, selected_year_data)  
      
      tagList(
        tags$div(style = "border: 1px solid #ccc; padding: 20px; margin: 10px; 
                    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); 
                    border-radius: 10px; background: linear-gradient(135deg, #f8f8f8, #e3e3e3);",
                 tags$p(style = "font-weight: bold; margin-bottom: 10px;", paste("Year:", selected_year)),
                 tags$p(style = "margin-bottom: 10px;", paste("Minimum Temperature:", selected_year_data$MinTempYear, "°C")),
                 tags$p(style = "margin-bottom: 10px;", paste("Maximum Temperature:", selected_year_data$MaxTempYear, "°C")),
                 tags$p(style = "margin-bottom: 10px;", paste("Average Temperature:", selected_year_data$AvgTempYear, "°C"))
        ),
        tags$div(style = "border: 1px solid #ccc; padding: 20px; margin: 10px; 
                    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); 
                    border-radius: 10px; background: linear-gradient(135deg, #f8f8f8, #e3e3e3);",
                 tags$p(style = "font-weight: bold; margin-bottom: 10px;", "Compared to historical data:"),
                 
                 tags$p(HTML(paste("Minimum Temperature Change:",
                                   ifelse(min_temp_change == "No data", min_temp_change,
                                          paste(min_temp_change, "%",
                                                ifelse(min_temp_change > 0,
                                                       "<span style='color:red;'>&#9650;</span>",  
                                                       "<span style='color:green;'>&#9660;</span>")  
                                          ))))),
                 
                 tags$p(HTML(paste("Maximum Temperature Change:",
                                   ifelse(max_temp_change == "No data", max_temp_change,
                                          paste(max_temp_change, "%",
                                                ifelse(max_temp_change > 0,
                                                       "<span style='color:red;'>&#9650;</span>", 
                                                       "<span style='color:green;'>&#9660;</span>") 
                                          )))))
        )
      )
    })
    
  })
  
  # Supplementary data in temperature plots
  output$tempDetails <- renderUI({
    tagList(
      tags$div(style = "border: 1px solid #ccc; padding: 20px; margin: 10px; 
                    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); 
                    border-radius: 10px; background: linear-gradient(135deg, #f8f8f8, #e3e3e3);",
               tags$p(style = "font-weight: bold; margin-bottom: 10px;", "Year: 2017"),  
               tags$p(style = "margin-bottom: 10px;", "Minimum Temperature: 10°C"), 
               tags$p(style = "margin-bottom: 10px;", "Maximum Temperature: 30°C"), 
               tags$p(style = "margin-bottom: 10px;", "Average Temperature: 20°C")  
      ),
      tags$div(style = "border: 1px solid #ccc; padding: 20px; margin: 10px; 
                    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); 
                    border-radius: 10px; background: linear-gradient(135deg, #f8f8f8, #e3e3e3);",
               tags$p(style = "font-weight: bold; margin-bottom: 10px;", "Compared to historical data:"), 
               tags$p(HTML(paste("Minimum Temperature Change: 5%",
                                 "<span style='color:red;'>&#9650;</span>"))),
               tags$p(HTML(paste("Maximum Temperature Change: -3%",
                                 "<span style='color:green;'>&#9660;</span>")))
      )
    )
  })
  
  
  
  
  # Supplementary data in wind map
  output$windInfo <- renderUI({
    selected_location <- input$location_selection
    filtered_data <- if (selected_location == "All") {
      data
    } else {
      data %>% filter(Location == selected_location)
    }
    if (nrow(filtered_data) > 0) {
      max_wind_speed <- max(filtered_data$WindGustSpeed, na.rm = TRUE) 
      avg_wind_speed <- mean(filtered_data$WindGustSpeed, na.rm = TRUE)  
      max_wind_direction <- filtered_data$WindGustDir[which.max(filtered_data$WindGustSpeed)]  
      
      tagList(
        tags$div(
          style = "border: 2px solid #cccccc; padding: 20px; 
                 background: linear-gradient(135deg, #e0e0e0, #f9f9f9); 
                 box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); 
                 border-radius: 10px; width: 100%; font-size: 12px;",  
          h4("Wind Information:", style = "color: #333; text-align: center; font-weight: bold; font-size: 14px;"), 
          p(HTML(paste("<span style='font-weight: normal;'>Location:</span> <strong>", selected_location, "</strong>"))),
          p(HTML(paste("<span style='font-weight: normal;'>Maximum Wind Speed:</span> <strong>", round(max_wind_speed, 2), " km/h</strong>"))),
          p(HTML(paste("<span style='font-weight: normal;'>Average Wind Speed:</span> <strong>", round(avg_wind_speed, 2), " km/h</strong>"))),
          p(HTML(paste("<span style='font-weight: normal;'>Direction of Maximum Wind Speed:</span> <strong>", max_wind_direction, "</strong>")))
        )
      )
    } else {
      tags$div(
        style = "border: 2px solid #cccccc; padding: 20px; margin: 10px;
               background: linear-gradient(135deg, #e0e0e0, #f9f9f9); 
               box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); 
               border-radius: 10px; width: 100%; font-size: 12px;",  
        h4("Wind Information:", style = "color: #333; text-align: center; font-weight: bold; font-size: 14px;"), 
        p("No data available for this location.")
      )
    }
  })
  
  
  # Calculate and output the correlation coefficient
  output$correlation_info <- renderText({
    correlation_data <- data %>%
      filter(Location == input$location) %>%
      filter(Date >= input$dateRange[1] & Date <= input$dateRange[2]) %>%
      filter(!is.na(WindGustSpeed), !is.na(Rainfall), !is.na(.data[[input$colorVar]])) 
    
    if (nrow(correlation_data) < 2) {
      return("Not enough data available to calculate correlation.")
    }
    
    correlation_value <- cor(correlation_data$WindGustSpeed, correlation_data$Rainfall, use = "complete.obs")
    paste("Correlation between Wind Gust Speed and Rainfall:", round(correlation_value, 2))
  })
  
  
  # Generate a graph of humidity versus rainfall
  output$tempHumidityPlot <- renderGirafe({
    selected_location <- input$location_selection
    
    filtered_data <- if (selected_location == "All") {
      data
    } else {
      data %>% filter(Location == selected_location)
    }
    
    selected_time <- input$time_selection
    
    if (selected_time == "9:00 AM") {
      temp_col <- "Temp9am"
      hum_col <- "Humidity9am"
    } else if (selected_time == "3:00 PM") {
      temp_col <- "Temp3pm"
      hum_col <- "Humidity3pm"
    } else {
      filtered_data$AvgTemp <- (filtered_data$Temp9am + filtered_data$Temp3pm) / 2
      filtered_data$AvgHumidity <- (filtered_data$Humidity9am + filtered_data$Humidity3pm) / 2
      temp_col <- "AvgTemp"
      hum_col <- "AvgHumidity"
    }
    
    model <- lm(as.formula(paste(hum_col, "~", temp_col)), data = filtered_data)
    intercept <- round(coef(model)[1], 2)
    slope <- round(coef(model)[2], 2)
    
    equation <- paste0("y = ", slope, "x + ", intercept)
    
    p <- ggplot(filtered_data, aes(x = !!sym(temp_col), y = !!sym(hum_col))) +
      geom_point_interactive(aes(
        color = !!sym(temp_col),
        tooltip = paste0(
          "Location: ", filtered_data$Location, "<br>",
          "Time: ", selected_time, "<br>",
          "Temperature: ", round(!!sym(temp_col), 2), " °C<br>",
          "Humidity: ", round(!!sym(hum_col), 2), " %<br>"
        ),
        data_id = !!sym(temp_col)
      ), alpha = 0.7, size = 2) + 
      geom_smooth(method = "lm", se = TRUE, color = "black", linetype = "dashed") + 
      scale_color_gradient(
        low = "lightblue",  
        high = "#204579"   
      ) +
      annotate("text", x = Inf, y = Inf, label = equation, hjust = 1.1, vjust = 2, size = 5, color = "black", parse = FALSE) +
      labs(title = paste(selected_time, "Temperature vs Humidity -", selected_location),
           x = "Temperature (°C)", y = "Humidity (%)") + 
      theme_minimal() +
      theme(
        plot.title = element_text(hjust = 0.5, face = "bold", size = 20, family = "Bahnschrift", color = "#0d649c"),  
        axis.title = element_text(size = 12, face = "bold"),  
        axis.text = element_text(size = 10), 
        legend.title = element_text(size = 12),  
        legend.text = element_text(size = 10)
      )
    
    girafe(ggobj = p, width_svg = 8, height_svg = 6)
  })
  
  
  
  
  output$dataTable <- renderDataTable({
    filtered_data()
  }, options = list(
    pageLength = 10,       
    searching = TRUE,      
    ordering = TRUE,      
    lengthChange = FALSE  
  ))
  
  
  
  # Wind Rose Plot
  output$windPlot <- renderGirafe({
    req(input$location_selection)
    
    if ("Date" %in% names(data)) {
      data <- data %>%
        mutate(
          Date = as.Date(Date, tryFormats = c("%Y-%m-%d", "%d/%m/%Y", "%m/%d/%Y")),
          Year = as.numeric(format(Date, "%Y"))
        )
    } else {
      showNotification("The dataset does not have a 'Date' column.", type = "error")
      return(NULL)
    }
    
    wind_data <- data %>%
      filter(Location == input$location_selection) %>%
      group_by(WindGustDir) %>%
      summarise(AvgWindGustSpeed = round(mean(WindGustSpeed, na.rm = TRUE), 2)) %>%
      filter(!is.na(WindGustDir), !is.na(AvgWindGustSpeed))
    
    if (nrow(wind_data) == 0) {
      ggplot() +
        annotate("text", x = 0.5, y = 0.5, label = "No wind data available for the selected location.",
                 size = 8, color = "#336699", hjust = 0.5, vjust = 0.5) +
        theme_void()
    } else {
      max_speed <- max(wind_data$AvgWindGustSpeed, na.rm = TRUE)
      max_speed <- ifelse(max_speed < 20, 20, max_speed)
      
      p <- ggplot(wind_data, aes(x = factor(WindGustDir, levels = c("N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW")), 
                                 y = AvgWindGustSpeed)) +
        geom_bar_interactive(aes(tooltip = paste("Direction: ", WindGustDir, "<br>Avg Speed: ", AvgWindGustSpeed, " km/h"),
                                 data_id = WindGustDir, fill = AvgWindGustSpeed), 
                             stat = "identity", width = 1, color = "black") +
        coord_polar(start = -pi/2) +
        scale_fill_gradientn(
          colors = c("lightblue", "yellow", "orange", "red"),
          limits = c(0, max_speed),
          guide = guide_colorbar(barwidth = 40)
        ) +
        labs(title = paste("Wind Gust Speed by Direction in", input$location_selection),
             x = "Wind Direction", y = "Average Gust Speed (km/h)") +
        theme_minimal() +
        theme(
          axis.text.y = element_blank(),
          axis.ticks = element_blank(),
          panel.grid = element_blank(),
          axis.text.x = element_text(size = 12, face = "bold", color = "black"),
          plot.title = element_text(hjust = 0.5, face = "bold", size = 20, color = "#0d649c"), 
          legend.position = "bottom", 
          legend.direction = "horizontal" 
        ) +
        ylim(0, max_speed) +
        geom_hline(yintercept = seq(5, max_speed, by = 5), color = "gray70", linetype = "dashed") +  
        geom_vline(xintercept = seq(0, 360, by = 30), color = "gray70", linetype = "dashed")
      
      girafe(ggobj = p, width_svg = 8, height_svg = 6) %>%
        girafe_options(
          opts_hover(css = "stroke-width:3px; fill-opacity:1;"),
          opts_selection(
            type = "single",
            css = "stroke-width:3px; fill-opacity:1;"
          )
        )
    }
  })
  
  observeEvent(input$windPlot_selected, {
    req(input$windPlot_selected)
    
    selected_direction <- input$windPlot_selected
    
    trend_data <- data %>%
      filter(Location == input$location_selection, WindGustDir == selected_direction) %>%
      mutate(Year = as.numeric(format(as.Date(Date), "%Y"))) %>%  # 确保 Year 列存在
      group_by(Year) %>%
      summarise(AvgWindGustSpeed = round(mean(WindGustSpeed, na.rm = TRUE), 2))
    
    showModal(modalDialog(
      title = paste("Wind Gust Speed Trend for", selected_direction),
      girafeOutput("trendPlot"),
      easyClose = TRUE,
      footer = modalButton("Close")
    ))
    
    output$trendPlot <- renderGirafe({
      min_point <- trend_data %>% filter(AvgWindGustSpeed == min(AvgWindGustSpeed))
      max_point <- trend_data %>% filter(AvgWindGustSpeed == max(AvgWindGustSpeed))
      
      x_range <- range(trend_data$Year)
      y_range <- range(trend_data$AvgWindGustSpeed)
      
      p <- ggplot(trend_data, aes(x = Year, y = AvgWindGustSpeed)) +
        geom_line(size = 1.5, color = "#204579") + 
        geom_point_interactive(aes(tooltip = paste("Year: ", Year, "<br>Avg Wind Gust: ", AvgWindGustSpeed, " km/h"),
                                   data_id = Year),
                               size = 3, color = "#204579") +
        
        geom_text_interactive(data = max_point, aes(label = paste(AvgWindGustSpeed, " km/h"),
                                                    tooltip = paste("Year: ", Year, "<br>Avg Wind Gust: ", AvgWindGustSpeed, " km/h"),
                                                    data_id = Year),
                              vjust = -1.5,  
                              size = 4, color = "black") +
        geom_text_interactive(data = min_point, aes(label = paste(AvgWindGustSpeed, " km/h"),
                                                    tooltip = paste("Year: ", Year, "<br>Avg Wind Gust: ", AvgWindGustSpeed, " km/h"),
                                                    data_id = Year),
                              vjust = 1.5,  
                              size = 4, color = "black") +
        labs(x = "Year", y = "Avg Wind Gust Speed (km/h)") +
        theme_minimal() +
        theme(
          plot.title = element_text(hjust = 0.5, face = "bold", size = 20, color = "#0d649c"), 
          axis.title = element_text(size = 12),
          axis.text = element_text(size = 10)
        ) +
        xlim(x_range[1] - 1, x_range[2] + 1) +
        ylim(y_range[1] - 2, y_range[2] + 2)
      
      girafe(ggobj = p, width_svg = 8, height_svg = 6) %>%
        girafe_options(
          opts_hover(css = "stroke-width:3px; fill-opacity:1;"),  
          opts_selection(
            type = "single",
            css = "stroke-width:3px; fill-opacity:1;"  
          )
        )
    })
    
    
    
    
    
    
    
    
    
    
  })
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  output$windRainPlot <- renderGirafe({
    plot_data <- filtered_data() %>%
      filter(Location == input$location) %>%
      filter(Date >= input$dateRange[1] & Date <= input$dateRange[2]) %>%
      filter(!is.na(WindGustSpeed), !is.na(Rainfall)) %>%
      mutate(id = row_number())
    
    if (nrow(plot_data) == 0) {
      return(NULL)
    }
    
    if (input$colorVar == "None") {
      p <- ggplot(plot_data, aes(x = WindGustSpeed, y = Rainfall)) +
        geom_point_interactive(aes(tooltip = paste("Wind Gust: ", WindGustSpeed, " km/h", "<br>Rainfall: ", Rainfall, " mm"),
                                   data_id = id),
                               size = 3, alpha = 0.7, color = "blue") +
        geom_smooth(method = "lm", se = TRUE, color = "red", linetype = "dashed") +
        labs(title = paste("Wind Gust Speed vs Rainfall in", input$location),
             x = "Wind Gust Speed (km/h)", y = "Rainfall (mm)") +
        theme_minimal() +
        theme(
          plot.title = element_text(hjust = 0.5, size = 20, face = "bold", family = "Bahnschrift", color = "#0d649c")
        )
    } else {
      p <- ggplot(plot_data, aes(x = WindGustSpeed, y = Rainfall, color = !!sym(input$colorVar))) +
        geom_point_interactive(aes(tooltip = paste("Wind Gust: ", WindGustSpeed, " km/h", "<br>Rainfall: ", Rainfall, " mm",
                                                   "<br>", input$colorVar, ": ", !!sym(input$colorVar)),
                                   data_id = id),
                               size = 3, alpha = 0.7) +
        geom_smooth(method = "lm", se = TRUE, color = "red", linetype = "dashed") +
        labs(title = paste("Wind Gust Speed vs Rainfall in", input$location),
             x = "Wind Gust Speed (km/h)", y = "Rainfall (mm)",
             color = input$colorVar) +
        theme_minimal() +
        theme(
          plot.title = element_text(hjust = 0.5, size = 20, face = "bold", family = "Bahnschrift", color = "#0d649c")
        )
    }
    
    girafe(ggobj = p, width_svg = 8, height_svg = 6) %>%
      girafe_options(
        opts_hover(css = "stroke-width:3px; fill-opacity:1;"),  # Highlight on hover
        opts_selection(
          type = "single",
          css = "stroke-width:3px; fill-opacity:1;"  # Style for selected point
        )
      )
  })
  
  
  
  
  
  
  
  
  
  
  # Listen to city and season selection events and update the chart
  observeEvent(c(input$city_am_pm, input$season), {
    city_temp_data()  
  })
  
  
  # Logic for handling random city buttons
  observeEvent(input$random_city, {
    random_city <- sample(unique(data$Location), 1)
    updateSelectInput(session, "city", selected = random_city)
  })
  
  # Update min and max of sliderInput
  observeEvent(input$city, {
    city_data <- data %>% filter(Location == input$city)
    year_min <- min(as.numeric(format(city_data$Date, "%Y")), na.rm = TRUE)
    year_max <- max(as.numeric(format(city_data$Date, "%Y")), na.rm = TRUE)
    
    if (is.na(year_min) || is.na(year_max)) {
      showNotification("No data available for the selected city.", type = "error")
      return()
    }
    
    updateSliderInput(session, "yearSlider",
                      min = year_min,
                      max = year_max,
                      value = c(year_min, year_max))
  })
  
  
  # Monitor the slider's year changes and filter the data
  filtered_data <- reactive({
    data %>%
      filter(as.numeric(format(as.Date(Date), "%Y")) >= input$yearSlider[1] &  
               as.numeric(format(as.Date(Date), "%Y")) <= input$yearSlider[2])   
  })
  
  # Use manually defined city coordinates
  city_coordinates <- data.frame(Location = unique(data$Location)) %>%
    rowwise() %>%
    mutate(coords = list(get_coordinates(Location))) %>%
    mutate(latitude = coords[1], longitude = coords[2]) %>%
    ungroup() %>%
    filter(!is.na(latitude) & !is.na(longitude))
  
  # Calculate total rainfall for each city
  rainfall_summary <- reactive({
    filtered_data() %>%
      group_by(Location) %>%
      summarise(
        Total_Rainfall = sum(Rainfall, na.rm = TRUE),
        Mean_Rainfall = mean(Rainfall, na.rm = TRUE),
        Max_Rainfall = max(Rainfall, na.rm = TRUE),
        Min_Rainfall = min(Rainfall, na.rm = TRUE)
      ) %>%
      left_join(city_coordinates, by = "Location") %>%
      filter(!is.na(latitude) & !is.na(longitude))
  })
  
  
  # Show Leaflet map
  output$rainfallTitle <- renderUI({
    tags$div(style = "text-align: center; margin-bottom: -15px;",
             tags$p(style = "font-weight: bold; font-size: 24px; color: #0d649c;",
                    "Rainfall Summary Map") 
    )
  })
  
  
  output$rainfallMap <- renderLeaflet({
    pal <- colorNumeric("Blues", domain = rainfall_summary()$Total_Rainfall)
    
    leaflet(rainfall_summary()) %>%
      addTiles() %>%
      setView(lng = 133.7751, lat = -25.2744, zoom = 4) %>%
      addCircleMarkers(
        lng = ~longitude, lat = ~latitude,
        color = "black",
        stroke = TRUE,
        weight = 2,
        fillColor = ~pal(Total_Rainfall),
        fillOpacity = 0.85,
        radius = ~log(Total_Rainfall + 1) * 1.2,
        label = ~paste(
          "<strong>", Location, "</strong><br>",
          "<b>Total Rainfall:</b>", Total_Rainfall, "mm<br>",
          "<b>Average Rainfall:</b>", round(Mean_Rainfall, 2), "mm<br>",
          "<b>Max Rainfall:</b>", Max_Rainfall, "mm<br>",
          "<b>Min Rainfall:</b>", Min_Rainfall, "mm"
        ) %>% lapply(htmltools::HTML),  
        layerId = ~Location 
      )
  })
  
  
  # Monitor city click events
  observeEvent(input$rainfallMap_marker_click, {
    city <- input$rainfallMap_marker_click$id  
    
    city_data <- filtered_data() %>%
      filter(Location == city) %>%
      filter(!is.na(Rainfall) & is.finite(Rainfall), !is.na(Date)) %>%
      group_by(Date) %>%
      summarise(Daily_Rainfall = sum(Rainfall, na.rm = TRUE))
    
    # Render a histogram
    output$rainfallPlot <- renderPlot({
      suppressWarnings({
        year_range_start <- as.Date(paste(input$yearSlider[1], "-01-01", sep = ""))
        year_range_end <- as.Date(paste(input$yearSlider[2], "-12-31", sep = ""))
        p <- ggplot(city_data, aes(x = Date, y = Daily_Rainfall)) +
          geom_area(fill = "#3498db", alpha = 0.5) +
          geom_line(color = "#3498db", size = 0.8) +
          labs(title = paste("Daily Rainfall in", city),
               x = "Date", y = "Rainfall (mm)") +
          scale_x_date(limits = c(year_range_start, year_range_end)) +  
          theme_minimal() +
          theme(
            plot.title = element_text(color = "#3498db", size = 14, face = "bold"),
            axis.title = element_text(color = "#3498db")
          )
        
        print(p)
      })
    })
    
    
    # Listen to click events and display information
    output$click_info <- renderUI({
      click <- input$plot_click
      if (is.null(click)) return(NULL)
      nearest_point <- city_data[which.min(abs(as.numeric(city_data$Date) - click$x)),]
      wellPanel(
        p(paste("Date: ", nearest_point$Date)),
        p(paste("Rainfall: ", nearest_point$Daily_Rainfall, "mm"))
      )
    })
    
  })
  
  
  output$rainfallPlot <- renderPlot({
    if (is.null(input$rainfallMap_marker_click$id)) {
      ggplot() +
        labs(title = "Click on a city to view rainfall information") +
        theme_minimal()
    }
  })
}



shinyApp(ui = ui, server = server)